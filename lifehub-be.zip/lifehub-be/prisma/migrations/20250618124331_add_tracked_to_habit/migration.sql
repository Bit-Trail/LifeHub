-- AlterTable
ALTER TABLE `habit` ADD COLUMN `tracked` JSON NOT NULL;
