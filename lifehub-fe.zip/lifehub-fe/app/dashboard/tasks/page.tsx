"use client";

import { useEffect, useState } from "react";
import { getTasks, getHabits, getJournals, getGoals } from "@/lib/api";
import { Task, Habit, Journal, Goal } from "@/types";
import { TaskCard } from "@/components/cards/TaskCard";
import { GoalCard } from "@/components/cards/GoalCard";
import { HabitCard } from "@/components/cards/HabitCard";
import { JournalCard } from "@/components/cards/JournalCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function DashboardPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [journals, setJournals] = useState<Journal[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("personal");

  const fetchData = async () => {
    const [taskRes, habitRes, journalRes, goalRes] = await Promise.all([
      getTasks(),
      getHabits(),
      getJournals(),
      getGoals(),
    ]);
    setTasks(taskRes);
    setHabits(habitRes);
    setJournals(journalRes);
    setGoals(goalRes);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredTasks = tasks.filter(
    (task) => task.category === selectedCategory
  );

  return (
    <div className="flex flex-col space-y-8">
      {/* Summary Header */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
        <TaskCard tasks={filteredTasks} />
        <HabitCard habits={habits} />
        <GoalCard goals={goals} />
        <JournalCard journals={journals} />
      </div>

      {/* Task Category Switch */}
      <Tabs defaultValue="personal" onValueChange={setSelectedCategory}>
        <TabsList className="w-fit">
          <TabsTrigger value="personal">Personal</TabsTrigger>
          <TabsTrigger value="professional">Professional</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Charts + Lists */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left Graph or Data Section */}
        <div className="lg:col-span-2 rounded-xl border bg-background p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Tasks Overview</h3>
          <ul className="text-sm text-muted-foreground list-disc list-inside">
            {filteredTasks.slice(0, 5).map((task) => (
              <li key={task.id}>{task.title}</li>
            ))}
            {filteredTasks.length === 0 && <li>No tasks available</li>}
          </ul>
        </div>

        {/* Right Summary Box */}
        <div className="grid gap-4">
          <div className="rounded-xl border bg-background p-4">
            <h4 className="text-sm font-medium">Active Habits</h4>
            <ul className="text-sm text-muted-foreground mt-2 list-disc list-inside">
              {habits.slice(0, 3).map((habit) => (
                <li key={habit.id}>{habit.title}</li>
              ))}
              {habits.length === 0 && <li>No habits</li>}
            </ul>
          </div>

          <div className="rounded-xl border bg-background p-4">
            <h4 className="text-sm font-medium">Goals In Progress</h4>
            <ul className="text-sm text-muted-foreground mt-2 list-disc list-inside">
              {goals.slice(0, 3).map((goal) => (
                <li key={goal.id}>{goal.title}</li>
              ))}
              {goals.length === 0 && <li>No goals</li>}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
